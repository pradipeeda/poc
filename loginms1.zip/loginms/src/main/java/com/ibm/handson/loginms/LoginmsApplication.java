package com.ibm.handson.loginms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginmsApplication.class, args);
	}

}
