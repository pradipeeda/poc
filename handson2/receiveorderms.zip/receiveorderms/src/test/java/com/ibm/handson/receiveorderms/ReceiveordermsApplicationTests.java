package com.ibm.handson.receiveorderms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceiveordermsApplicationTests {

	@Test
	void contextLoads() {
	}

}
